'use strict';

// In-memory relay state: tabId -> { selector, selectorText, crawlRows, crawlPage, crawlComplete, crawlPages }
// Using chrome.storage.session for persistence across service worker sleep cycles
const STORE_PREFIX = 'ids_tab_';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = sender.tab?.id ?? msg.tabId;

  if (msg.type === 'pickerSelected') {
    storeTabState(tabId, { selector: msg.selector, selectorText: msg.selectorText });
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'crawlProgress') {
    storeTabState(tabId, { crawlRows: msg.allRows, crawlPage: msg.page, crawlComplete: false });
    // Relay to popup (no-op if popup is closed)
    chrome.runtime.sendMessage(msg).catch(() => {});
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'crawlComplete') {
    storeTabState(tabId, {
      crawlRows: msg.allRows,
      crawlPage: msg.pages,
      crawlPages: msg.pages,
      crawlComplete: true
    });
    chrome.runtime.sendMessage(msg).catch(() => {});
    sendResponse({ ok: true });
    return true;
  }

  if (msg.action === 'getTabState') {
    getTabState(msg.tabId).then(state => sendResponse(state || {}));
    return true;
  }

  if (msg.action === 'setTabState') {
    storeTabState(msg.tabId, msg.state).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.action === 'clearTabState') {
    chrome.storage.session.remove(STORE_PREFIX + msg.tabId).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.action === 'startDeepScrape') {
    startDeepScrape(msg).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.action === 'stopDeepScrape') {
    DEEP.active = false;
    sendResponse({ ok: true });
    return true;
  }

  if (msg.action === 'getPostMeta') {
    getPostMeta(msg.urls || []).then(res => sendResponse({ ok: true, meta: res }));
    return true;
  }

  if (msg.action === 'startOcr') {
    startOcr(msg).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.action === 'stopOcr') {
    OCR.active = false;
    sendResponse({ ok: true });
    return true;
  }

  if (msg.action === 'startReviewCrawl') {
    startReviewCrawl(msg).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.action === 'stopReviewCrawl') {
    REV.active = false;
    sendResponse({ ok: true });
    return true;
  }

  return false;
});

// ══════════════════════════════════════════════════════════════════════════
//  REVIEW CRAWL (Amazon) — walk the star-filtered review pages in a background
//  tab until the per-star target is met. Uses Amazon's own filter URLs
//  (?filterByStar=five_star&pageNumber=N) so we get exactly the stars asked for.
// ══════════════════════════════════════════════════════════════════════════
const REV = { active: false };

async function startReviewCrawl(msg) {
  const { base, targets, delayMs, maxPagesPerStar } = msg;
  REV.active = true;
  const all = [], seen = new Set();
  const key = r => (r.Reviewer || '') + '|' + (r.Review || r.Title || '').slice(0, 60);
  const gap = Math.max(800, delayMs || 1500);
  const maxPages = maxPagesPerStar || 20;

  let tab;
  try { tab = await chrome.tabs.create({ url: 'about:blank', active: false }); }
  catch (e) { REV.active = false; chrome.runtime.sendMessage({ type: 'reviewComplete', rows: [], error: 'could not open tab' }).catch(() => {}); return; }

  const STARS = [['five_star', 5], ['four_star', 4], ['three_star', 3], ['two_star', 2], ['one_star', 1]];
  try {
    for (const [starKey, starNum] of STARS) {
      const target = targets[starKey] || 0;
      if (!target || !REV.active) continue;
      let page = 1, got = 0;
      while (REV.active && got < target && page <= maxPages) {
        const url = `${base}?filterByStar=${starKey}&pageNumber=${page}&reviewerType=all_reviews&sortBy=recent`;
        try { await chrome.tabs.update(tab.id, { url }); } catch (_) { break; }
        await waitForComplete(tab.id, 20000);
        await sleep(1800); // let reviews render

        let rows = [];
        try {
          const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: extractAmazonReviewsPage });
          rows = (res && res.result) || [];
        } catch (_) {}
        if (!rows.length) break;

        let added = 0;
        for (const r of rows) {
          if (got >= target) break;
          const k = key(r);
          if (!seen.has(k)) { seen.add(k); all.push(r); added++; got++; }
        }
        chrome.runtime.sendMessage({ type: 'reviewProgress', star: starNum, got, target, total: all.length, page }).catch(() => {});
        if (added === 0) break;      // page had only duplicates / end of list
        page++;
        if (got < target && REV.active) await sleep(gap);
      }
    }
  } finally {
    try { await chrome.tabs.remove(tab.id); } catch (_) {}
  }
  REV.active = false;
  chrome.runtime.sendMessage({ type: 'reviewComplete', rows: all, count: all.length }).catch(() => {});
}

// Self-contained Amazon review extractor injected into each review page.
function extractAmazonReviewsPage() {
  const COLS = ['Rating', 'Rating (number)', 'Title', 'Review', 'Reviewer', 'Date',
                'Verified', 'Helpful', 'Helpful (number)', 'Variant', 'Product', 'URL'];
  const abs = href => { if (!href) return location.href.split('?')[0]; try { return new URL(href, location.origin).href; } catch (_) { return href; } };
  const product = (document.querySelector('[data-hook="product-link"], #productTitle, [data-hook="cr-product-title"]')?.textContent
    || document.title.replace(/\s*[:|-].*$/, '')).trim();
  const items = [...document.querySelectorAll('[data-hook="review"]')];
  return items.map(it => {
    const row = {}; COLS.forEach(c => row[c] = '');
    const rt = (it.querySelector('[data-hook="review-star-rating"] .a-icon-alt, [data-hook="cmps-review-star-rating"] .a-icon-alt')?.textContent || '').trim();
    row.Rating = rt; const rm = rt.match(/([\d.]+)\s*out of\s*5/i); if (rm) row['Rating (number)'] = rm[1];
    const te = it.querySelector('[data-hook="review-title"]');
    if (te) { const sp = [...te.querySelectorAll('span')].map(s => s.textContent.trim()).filter(t => t && !/out of 5/i.test(t) && !/^\d+(\.\d)?$/.test(t)); row.Title = (sp.pop() || te.textContent.trim()).replace(/\s+/g, ' '); }
    row.Review = ((it.querySelector('[data-hook="review-body"]') || {}).innerText || '').trim().replace(/\s+/g, ' ');
    row.Reviewer = (it.querySelector('.a-profile-name')?.textContent || '').trim();
    const dt = (it.querySelector('[data-hook="review-date"]')?.textContent || '').trim(); const dm = dt.match(/on\s+(.+)$/i); row.Date = dm ? dm[1].trim() : dt;
    row.Verified = it.querySelector('[data-hook="avp-badge"]') ? 'Yes' : '';
    const hp = (it.querySelector('[data-hook="helpful-vote-statement"]')?.textContent || '').trim(); row.Helpful = hp;
    const hm = hp.replace(/,/g, '').match(/(\d+)/); if (hm) row['Helpful (number)'] = hm[1]; else if (/one|a person/i.test(hp)) row['Helpful (number)'] = '1';
    row.Variant = (it.querySelector('[data-hook="format-strip"], .review-format-strip')?.textContent || '').trim().replace(/\s+/g, ' ');
    row.Product = product;
    const lk = it.querySelector('[data-hook="review-title"]');
    row.URL = lk && lk.getAttribute('href') ? abs(lk.getAttribute('href')) : location.href.split('?')[0];
    return row;
  }).filter(r => r.Review || r.Title);
}

// ══════════════════════════════════════════════════════════════════════════
//  IMAGE OCR — reads text from each post's image (PaddleOCR PP-OCRv4 via
//  onnxruntime-web, English/Latin), classifies the content type, and detects
//  the language. Heavy work runs in an offscreen document because the MV3
//  service worker can't provide a DOM/canvas + WASM runtime.
// ══════════════════════════════════════════════════════════════════════════
const OCR = { active: false, frames: 8 };

function secToClockSW(sec) {
  const s = Math.round(sec);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}`
           : `${m}:${String(r).padStart(2, '0')}`;
}

async function ensureOffscreen() {
  try {
    const has = await chrome.offscreen.hasDocument();
    if (has) return;
  } catch (_) {}
  try {
    await chrome.offscreen.createDocument({
      url: 'offscreen/ocr.html',
      reasons: ['DOM_SCRAPING'],
      justification: 'Run on-device OCR (PaddleOCR PP-OCRv4 / WASM) on post images.',
    });
  } catch (e) {
    // Already exists / race — ignore
  }
}

async function fetchAsDataUrl(url) {
  const resp = await fetch(url);
  if (!resp.ok) throw new Error('HTTP ' + resp.status);
  const blob = await resp.blob();
  return await new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onload = () => res(fr.result);
    fr.onerror = () => rej(new Error('read failed'));
    fr.readAsDataURL(blob);
  });
}

// Get the exact posting date (+ duration) for a small set of posts by OPENING
// each in a real background tab and scraping the rendered page — the same
// deep-scrape path as the per-post enrichment. No fetch()/guesswork: this is
// what makes the first/last-post date range accurate on Instagram etc.
async function getPostMeta(urls) {
  const out = {};
  for (const url of urls) {
    if (!url) continue;
    try {
      const d = await openAndExtract(url, { date: true });
      out[url] = { date: normalizeDate(d && d.Date), durationSec: (d && d.DurationSec) || '' };
    } catch (e) {
      out[url] = { date: '', durationSec: '', error: String(e).slice(0, 100) };
    }
  }
  return out;
}

// Normalize any scraped date string to YYYY-MM-DD.
function normalizeDate(s) {
  if (!s) return '';
  const m = String(s).match(/(\d{4})-(\d{2})-(\d{2})/);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  const t = Date.parse(s);
  if (!isNaN(t)) { try { return new Date(t).toISOString().slice(0, 10); } catch (_) {} }
  return '';
}

async function getFullResImage(postUrl) {
  if (!postUrl) return '';

  // YouTube: derive the high-res thumbnail from the video id (no fetch needed)
  const yt = postUrl.match(/[?&]v=([\w-]{6,})/) || postUrl.match(/\/shorts\/([\w-]{6,})/);
  if (yt) return `https://i.ytimg.com/vi/${yt[1]}/maxresdefault.jpg`;

  let html = '';
  try {
    const resp = await fetch(postUrl, { credentials: 'include' });
    if (!resp.ok) return '';
    html = await resp.text();
  } catch (_) { return ''; }

  const deEnt = (s) => (s || '')
    .replace(/&amp;/g, '&').replace(/\\u0026/g, '&').replace(/\\\//g, '/');

  // og:image (handles both attribute orders)
  let m = html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)
       || html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i);
  if (m) return deEnt(m[1]);

  // Instagram embedded high-res image
  m = html.match(/"display_url":"([^"]+)"/) || html.match(/"display_src":"([^"]+)"/);
  if (m) return deEnt(m[1]);

  return '';
}

async function startOcr(msg) {
  const items = msg.items || [];   // [{ key, thumb }]
  OCR.active = true;
  await ensureOffscreen();

  let done = 0;
  for (const it of items) {
    if (!OCR.active) break;
    let text = '', conf = 0, err = '', durationSec = 0;
    try {
      // A reel keeps most of its text INSIDE the video, not on the cover frame,
      // so when we know the video URL we sample frames from it. Otherwise fall
      // back to the best still image we have.
      if (it.video) {
        const r = await chrome.runtime.sendMessage({
          target: 'offscreen', action: 'ocrVideo', url: it.video, maxFrames: OCR.frames || 8,
        });
        if (r && r.ok) { text = r.text; conf = r.conf; durationSec = r.duration || 0; }
        else { err = (r && r.error) || 'video ocr failed'; }
      }
      if (!text) {
        let imgUrl = it.image || it.thumb;
        try {
          const full = await getFullResImage(it.key);
          if (full) imgUrl = full;
        } catch (_) {}
        const dataUrl = await fetchAsDataUrl(imgUrl);
        const r = await chrome.runtime.sendMessage({ target: 'offscreen', action: 'ocr', dataUrl });
        if (r && r.ok) { text = r.text; conf = r.conf; } else if (!err) { err = (r && r.error) || 'ocr failed'; }
      }
    } catch (e) {
      err = String(e).slice(0, 120);
    }

    const language = detectLanguage(text, conf);
    const fields = {
      ImageText: text,
      ContentType: classifyContent(text),
      Language: language,
      _err: err,
    };
    // Reading the video also tells us its exact length - fill Duration for free.
    if (durationSec > 0) {
      fields.Duration = secToClockSW(durationSec);
      fields['Duration (sec)'] = String(Math.round(durationSec));
    }
    done++;
    chrome.runtime.sendMessage({ type: 'ocrProgress', done, total: items.length, key: it.key, fields }).catch(() => {});
  }

  OCR.active = false;
  chrome.runtime.sendMessage({ type: 'ocrComplete', count: done }).catch(() => {});
  // Tear down the OCR worker + offscreen doc to free memory
  try { await chrome.runtime.sendMessage({ target: 'offscreen', action: 'ocrDispose' }); } catch (_) {}
  try { await chrome.offscreen.closeDocument(); } catch (_) {}
}

// ── Language detection (the PP-OCRv4 model we ship reads English/Latin) ─────
function detectLanguage(text, conf) {
  if (!text) return '';
  const latin = (text.match(/[A-Za-z]/g) || []).length;
  const digits = (text.match(/[0-9]/g) || []).length;
  if (latin >= 2) return 'English';
  if (latin + digits >= 2) return 'English';
  return '';
}

// ── Content-type classification (keyword rules; editable) ───────────────────
function classifyContent(text) {
  const t = (text || '').toLowerCase();
  if (!t.trim()) return '';

  const festive = /\b(diwali|deepavali|holi|eid|christmas|xmas|new year|navratri|dussehra|dasara|dashain|raksha bandhan|rakhi|onam|pongal|ganesh|ganpati|durga|puja|pooja|lohri|baisakhi|festival|festive|greetings|wishes|shubh|celebrat|happy)\b/;
  const offer  = /(\b(sale|off|discount|offer|deal|deals|free|save|savings|flat|cashback|coupon|promo|lowest price|price drop|best price|upto|up to|buy now|shop now|limited time|mega|bumper)\b|%|₹|\brs\.?\b|\binr\b)/;
  const product = /\b(introducing|introduc|new|launch|launching|available|now available|presenting|meet the|range|feature|features|model|series|collection|variant|edition|specs?|powered by|all[- ]new)\b/;

  if (festive.test(t)) return 'Festive';
  if (offer.test(t)) return 'Offer-led';
  if (product.test(t)) return 'Product-led';
  return 'Informational';
}

// ══════════════════════════════════════════════════════════════════════════
//  DEEP SCRAPE — opens each post URL in a hidden tab, extracts the fields the
//  user selected, then closes the tab. Uses the user's own logged-in session.
// ══════════════════════════════════════════════════════════════════════════
const DEEP = { active: false };

async function startDeepScrape(msg) {
  const { urls, options, delayMs } = msg;
  const popupTabId = msg.tabId;
  DEEP.active = true;

  const results = {};                       // url -> extracted fields
  const gap = Math.max(800, delayMs || 2500);
  let done = 0;

  for (const url of urls) {
    if (!DEEP.active) break;
    try {
      results[url] = await openAndExtract(url, options);
    } catch (e) {
      results[url] = { _error: String(e).slice(0, 120) };
    }
    done++;
    // Report progress to the popup (no-op if popup is closed)
    chrome.runtime.sendMessage({
      type: 'deepProgress', done, total: urls.length, url, fields: results[url]
    }).catch(() => {});
    if (done < urls.length && DEEP.active) await sleep(gap);
  }

  DEEP.active = false;
  chrome.runtime.sendMessage({ type: 'deepComplete', results, count: done }).catch(() => {});
}

// Open one URL in an inactive tab, wait for it to load + render, run the
// extractor, then close the tab.
async function openAndExtract(url, options) {
  let tab;
  try {
    tab = await chrome.tabs.create({ url, active: false });
  } catch (e) {
    return { _error: 'could not open tab' };
  }
  const tabId = tab.id;
  try {
    await waitForComplete(tabId, 20000);
    await sleep(2500); // let the SPA render like/comment counts

    // Retry extraction up to 3 times if counts haven't rendered yet
    let data = {};
    for (let attempt = 0; attempt < 3; attempt++) {
      const [res] = await chrome.scripting.executeScript({
        target: { tabId },
        func: extractPostDetails,
        args: [options],
      });
      data = res?.result || {};
      const gotSomething = data.Date || data.Likes || data.Comments || data.Shares || data.CommentText;
      if (gotSomething) break;
      await sleep(1500);
    }
    return data;
  } finally {
    try { await chrome.tabs.remove(tabId); } catch (_) {}
  }
}

function waitForComplete(tabId, timeout) {
  return new Promise(resolve => {
    let settled = false;
    const finish = () => { if (!settled) { settled = true; chrome.tabs.onUpdated.removeListener(listener); resolve(); } };
    const listener = (id, info) => { if (id === tabId && info.status === 'complete') finish(); };
    chrome.tabs.onUpdated.addListener(listener);
    // Check current state immediately too
    chrome.tabs.get(tabId).then(t => { if (t.status === 'complete') finish(); }).catch(() => {});
    setTimeout(finish, timeout);
  });
}

// ── The per-post extractor (INJECTED into each post tab) ───────────────────
// Must be fully self-contained — it runs in the target page, not here.
// Strategy: read the numbers from the page's EMBEDDED JSON first (the most
// reliable source — Meta/YouTube ship engagement data inside <script> tags),
// then fall back to an aria-label / icon DOM scan, then to plain text.
// options: { date, likes, comments, shares, commentText, maxComments }
function extractPostDetails(options) {
  const host = location.hostname;
  const out = {};

  // ── Build a searchable blob of all inline JSON + the rendered HTML ──
  let scriptBlob = '';
  try {
    const scripts = document.querySelectorAll(
      'script[type="application/json"], script[type="application/ld+json"], script:not([src])'
    );
    for (const s of scripts) scriptBlob += '\n' + (s.textContent || '');
  } catch (_) {}
  const htmlBlob = (document.documentElement && document.documentElement.outerHTML) || '';
  const blob = scriptBlob + '\n' + htmlBlob;
  const bodyText = (document.body && document.body.innerText) || '';

  // firstMatch: try each regex against a source, return the first capture group
  const firstMatch = (patterns, src) => {
    src = src || blob;
    for (const re of patterns) {
      const m = src.match(re);
      if (m && m[1] != null && String(m[1]).length) return String(m[1]);
    }
    return '';
  };

  const unixToDate = (n) => {
    const num = parseInt(n, 10);
    if (!num) return '';
    const ms = num < 1e12 ? num * 1000 : num; // seconds vs ms
    try { return new Date(ms).toISOString().slice(0, 10); } catch (_) { return ''; }
  };

  const isFB = /facebook|fb\.com|fb\.watch/.test(host);
  const isIG = /instagram/.test(host);
  const isYT = /youtube|youtu\.be/.test(host);

  // ═══════════════════ DATE ═══════════════════
  // Robust multi-source date: any <time> datetime/title, JSON-LD
  // datePublished/uploadDate (Instagram posts/reels ship this), embedded unix
  // timestamps, meta tags, then a plain-text fallback.
  if (options.date) {
    let val = '';

    // 1) Any <time> element's datetime or title attribute
    try {
      for (const t of document.querySelectorAll('time')) {
        const d = t.getAttribute('datetime') || t.getAttribute('title') || '';
        if (d && /\d{4}/.test(d)) { val = d; break; }
      }
    } catch (_) {}

    // 2) JSON-LD / embedded JSON (the reliable source on Instagram)
    if (!val) {
      const iso = firstMatch([
        /"uploadDate"\s*:\s*"([^"]+)"/, /"datePublished"\s*:\s*"([^"]+)"/,
        /"publishDate"\s*:\s*"(\d{4}-\d{2}-\d{2}[^"]*)"/, /"uploadDate"\s*:\s*"(\d{4}-\d{2}-\d{2}[^"]*)"/,
      ]);
      if (iso) val = iso;
    }
    if (!val) {
      const ts = firstMatch([
        /"taken_at_timestamp"\s*:\s*(\d{9,13})/, /"taken_at"\s*:\s*(\d{9,13})/,
        /"device_timestamp"\s*:\s*(\d{9,13})/, /"creation_time"\s*:\s*(\d{9,13})/,
        /"publish_time"\s*:\s*(\d{9,13})/, /"created_time"\s*:\s*(\d{9,13})/,
      ]);
      if (ts) val = unixToDate(ts);
    }

    // 3) Meta tags
    if (!val) {
      const mt = document.querySelector('meta[property="article:published_time"], meta[itemprop="datePublished"], meta[property="og:updated_time"], meta[name="date"]');
      if (mt && mt.getAttribute('content')) val = mt.getAttribute('content');
    }

    // 4) Platform text fallbacks
    if (!val && isYT) val = firstMatch([/"dateText":\{"simpleText":"([^"]+)"/])
      || firstMatch([/(?:Premiered |Streamed live on |Published on |)([A-Z][a-z]{2} \d{1,2}, \d{4})/], bodyText);
    if (!val) val = firstMatch([/([A-Z][a-z]+ \d{1,2}, \d{4})/], bodyText)
      || firstMatch([/(\d{4}-\d{2}-\d{2})T\d{2}:\d{2}/]);

    out.Date = val || '';
  }

  // ═══════════════════ LIKES / REACTIONS ═══════════════════
  if (options.likes) {
    if (isFB) {
      out.Likes = firstMatch([
        /"reaction_count":\{"count":(\d+)/,
        /"i18n_reaction_count":"([\d.,KMB]+)"/,
        /"reactors":\{[^}]*"count":(\d+)/,
        /"reaction_count":\{[^}]*"count":(\d+)/,
      ]);
    } else if (isIG) {
      out.Likes = firstMatch([
        /"edge_media_preview_like":\{"count":(\d+)/,
        /"edge_liked_by":\{"count":(\d+)/,
        /"like_count":(\d+)/,
      ]);
    } else if (isYT) {
      out.Likes = firstMatch([
        /"accessibilityText":"([\d,]+) likes"/,
        /"label":"([\d,]+) likes"/,
        /"likeCount":"(\d+)"/,
        /"defaultText":\{[^}]*"accessibilityData":\{"label":"([\d,]+) likes/,
      ]);
    }
    // Fallback: aria-labels / visible text
    if (!out.Likes) out.Likes = scanCount(['like', 'reaction', 'react']) || firstMatch([/([\d.,]+[KMB]?)\s+(?:likes?|reactions?)/i], bodyText);
  }

  // ═══════════════════ COMMENTS (count) ═══════════════════
  if (options.comments) {
    if (isFB) {
      out.Comments = firstMatch([
        /"comment_count":\{"total_count":(\d+)/,
        /"comment_count":\{[^}]*"count":(\d+)/,
        /"comments":\{[^}]*"total_count":(\d+)/,
        /"total_comment_count":(\d+)/,
      ]);
    } else if (isIG) {
      out.Comments = firstMatch([
        /"edge_media_to_comment":\{"count":(\d+)/,
        /"edge_media_to_parent_comment":\{"count":(\d+)/,
        /"comment_count":(\d+)/,
      ]);
    } else if (isYT) {
      out.Comments = firstMatch([
        /"commentCount":\{"simpleText":"([\d,]+)"/,
        /"commentCount":"(\d+)"/,
        /"contextualInfo":\{"runs":\[\{"text":"([\d,]+)"/,
      ]);
    }
    if (!out.Comments) out.Comments = scanCount(['comment']) || firstMatch([/([\d.,]+[KMB]?)\s+comments?/i, /View all ([\d.,]+[KMB]?)\s+comments/i], bodyText);
  }

  // ═══════════════════ SHARES ═══════════════════
  if (options.shares) {
    if (isIG || isYT) {
      out.Shares = ''; // not publicly exposed on these platforms
    } else if (isFB) {
      out.Shares = firstMatch([
        /"share_count":\{"count":(\d+)/,
        /"i18n_share_count":"([\d.,KMB]+)"/,
        /"reshares":\{[^}]*"count":(\d+)/,
        /"share_count_reduced":"([\d.,KMB]+)"/,
      ]) || scanCount(['share', 'send']) || firstMatch([/([\d.,]+[KMB]?)\s+shares?/i], bodyText);
    } else {
      out.Shares = firstMatch([/([\d.,]+[KMB]?)\s+shares?/i], bodyText);
    }
  }

  // ═══════════════════ VIEWS (bonus — reels/videos) ═══════════════════
  // Deep scrape can also confirm/fill the view count from the post page.
  {
    let v = '';
    if (isFB) v = firstMatch([/"video_view_count":(\d+)/, /"play_count":(\d+)/, /"view_count":(\d+)/]);
    else if (isIG) v = firstMatch([/"video_view_count":(\d+)/, /"play_count":(\d+)/, /"video_play_count":(\d+)/]);
    else if (isYT) v = firstMatch([/"viewCount":"(\d+)"/, /"viewCount":\{"simpleText":"([\d,]+)/]);
    if (v) out.Views = v;
  }

  // ═══════════════════ DURATION ═══════════════════
  {
    const clock = (sec) => {
      sec = Math.round(Number(sec) || 0);
      if (sec <= 0) return '';
      const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
      const p = n => String(n).padStart(2, '0');
      return h > 0 ? `${h}:${p(m)}:${p(s)}` : `${m}:${p(s)}`;
    };
    let sec = '';
    if (isIG) { const d = firstMatch([/"video_duration":([\d.]+)/]); if (d) sec = parseFloat(d); }
    else if (isFB) {
      const ms = firstMatch([/"playable_duration_in_ms":(\d+)/]);
      const s = firstMatch([/"length_in_second":(\d+)/, /"playable_duration":(\d+)/]);
      if (ms) sec = parseInt(ms, 10) / 1000; else if (s) sec = parseInt(s, 10);
    } else if (isYT) {
      const ls = firstMatch([/"lengthSeconds":"(\d+)"/]);
      const ms = firstMatch([/"approxDurationMs":"(\d+)"/]);
      const lt = firstMatch([/"lengthText":\{[^}]*"simpleText":"([\d:]+)"/]);
      if (ls) sec = parseInt(ls, 10);
      else if (ms) sec = parseInt(ms, 10) / 1000;
      else if (lt) { out.Duration = lt; out.DurationSec = String(lt.split(':').reduce((a, n) => a * 60 + (+n), 0)); }
    }
    if (sec) { out.Duration = clock(sec); out.DurationSec = String(Math.round(sec)); }
  }

  // ═══════════════════ CAPTION (ALWAYS — the key fix) ═══════════════════
  // The full caption lives in the post's embedded JSON regardless of whether
  // it's a post or a reel, so deep scrape gets it consistently for both.
  {
    // decode a JSON string body (handles \n, \", \uXXXX escapes)
    const dec = (raw) => { try { return JSON.parse('"' + raw + '"'); } catch (_) { return raw.replace(/\\n/g, ' ').replace(/\\"/g, '"'); } };
    const S = '((?:[^"\\\\]|\\\\.)*)'; // a JSON string body with escapes
    let cap = '';
    if (isIG) {
      cap = firstMatch([
        new RegExp('"edge_media_to_caption":\\{"edges":\\[\\{"node":\\{"text":"' + S + '"'),
        new RegExp('"caption":\\{[^}]*"text":"' + S + '"'),
        new RegExp('"caption":"' + S + '"'),
        new RegExp('"accessibility_caption":"' + S + '"'),
      ]);
    } else if (isFB) {
      cap = firstMatch([
        new RegExp('"message":\\{"text":"' + S + '"'),
        new RegExp('"title":\\{"text":"' + S + '"'),
        new RegExp('"description":\\{"text":"' + S + '"'),
      ]);
    } else if (isYT) {
      cap = firstMatch([
        new RegExp('"title":\\{"runs":\\[\\{"text":"' + S + '"'),
        new RegExp('"title":\\{"simpleText":"' + S + '"'),
        new RegExp('"videoPrimaryInfoRenderer":\\{"title":\\{"runs":\\[\\{"text":"' + S + '"'),
      ]);
      if (!cap && document.title) cap = document.title.replace(/\s*-\s*YouTube\s*$/, '');
    }
    // Universal fallbacks that work on any platform's post page
    if (!cap) {
      const og = document.querySelector('meta[property="og:description"], meta[property="og:title"], meta[name="description"]');
      cap = og?.getAttribute('content') || '';
    }
    if (cap) out.Caption = dec(cap).trim().replace(/\s+/g, ' ').slice(0, 2000);
  }

  // ═══════════════════ COMMENT TEXT (top N) ═══════════════════
  if (options.commentText) {
    const max = options.maxComments || 20;
    let nodes = [];
    if (isYT) {
      nodes = [...document.querySelectorAll('ytd-comment-thread-renderer #content-text, #content-text')];
    } else if (isIG) {
      nodes = [...document.querySelectorAll('ul ul span[dir="auto"], ul li span[dir="auto"]')];
    } else if (isFB) {
      nodes = [...document.querySelectorAll('div[role="article"] div[dir="auto"], [aria-label="Comment"] ~ div div[dir="auto"]')];
    }
    const texts = nodes
      .map(n => (n.innerText || n.textContent || '').trim())
      .filter(t => t.length > 1)
      .slice(0, max);
    out.CommentText = texts.join('  |  ');
  }

  return out;

  // ── DOM helper: find a count near an icon/button whose aria-label matches ──
  // Handles Facebook reels where the number sits under a heart/comment/share
  // icon with NO adjacent word (so text-regex fails but aria-labels work).
  function scanCount(keywords) {
    const kw = new RegExp(keywords.join('|'), 'i');
    const isNum = (t) => /^[\d][\d.,]*\s*[KMB]?$/i.test((t || '').trim());
    // Candidate action elements: things with an aria-label mentioning the action
    const candidates = [...document.querySelectorAll(
      '[aria-label], [role="button"], a[href], div[role="button"]'
    )].filter(el => {
      const al = (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '');
      return kw.test(al);
    });
    for (const el of candidates) {
      // (a) the number may be baked into the aria-label itself
      const al = el.getAttribute('aria-label') || '';
      const m = al.match(/([\d.,]+\s*[KMB]?)/);
      if (m && isNum(m[1])) return m[1].replace(/\s/g, '');
      // (b) or a nearby sibling / descendant holds the number
      const scope = el.parentElement || el;
      const nums = [...scope.querySelectorAll('span, div')]
        .filter(n => n.children.length === 0 && isNum(n.textContent));
      if (nums.length) return nums[0].textContent.trim();
    }
    return '';
  }
}

async function storeTabState(tabId, patch) {
  if (!tabId) return;
  const key = STORE_PREFIX + tabId;
  try {
    const existing = await chrome.storage.session.get(key);
    const current = existing[key] || {};
    await chrome.storage.session.set({ [key]: { ...current, ...patch } });
  } catch (_) {
    // storage.session unavailable in very old Chrome — silently ignore
  }
}

async function getTabState(tabId) {
  if (!tabId) return {};
  const key = STORE_PREFIX + tabId;
  try {
    const result = await chrome.storage.session.get(key);
    return result[key] || {};
  } catch (_) {
    return {};
  }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
